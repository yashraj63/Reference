WORKSLOP SEGMENT v2 - NOTES
===========================
Timing: voiceover = ElevenLabs take 1 (voice: Aditya 2.0). The voice starts 1.5 s into the video (after the black
Chapter 3 title). word_timestamps.csv has start/end of every word (audio time and video time).
Word times are estimated from the audio's pauses plus syllable counts (not a speech-recognition transcript),
so expect roughly +/- 0.15 s per word.

Sources shown on screen (your headline PNGs):
- ANI / Adobe: Only 6.7% of Indian companies have scaled AI across workflows, 59% face hurdles: Report - Oct 14, 2026
- EY-CII (The AIdea of India: Outlook 2026): More than half of Indian organisations have converted less than 10% of GenAI pilots into production - Nov 16, 2025
- ANI / Workday: Nearly 40% of AI time savings are lost to rework: Report - Jan 15, 2026 (global study, not India-only)
- ETCIO / Freshworks: 27% of mid-market AI budget in India lost to complexity overhead, ~Rs 33,000 crore annually - May 29, 2026

Still worth checking before publishing:
- "Practically broken tools" is narration opinion, not a finding of the Freshworks report.
- "Kharab data foundation" has no source card in this cut (the Dun & Bradstreet 4% data-readiness stat was dropped).
- EY-CII headline date (Nov 16, 2025) is when the report was covered; the title says Outlook 2026.
